from app.repositories.auth_user_repository import AuthUserRepository
from app.models.auth_user import AuthUser
from werkzeug.security import generate_password_hash, check_password_hash

class AuthService:
    def __init__(self):
        self.repo = AuthUserRepository()

    def validar_login(self, email: str, password: str):
        """Retorna el usuario si (email,password) válidos, si no None."""
        user = self.repo.obtener_por_email(email.strip())
        # Usar verificación segura de contraseña
        if user and check_password_hash(user.password, password):
            return user
        return None

    def crear_usuario(self, nombre: str, email: str, password: str, is_admin: bool = False):
        """Crea un nuevo usuario en el sistema."""
        # Hashear la contraseña antes de persistir
        hashed = generate_password_hash(password)
        user = self.repo.obtener_por_email(email)
        if user:
            return None  # El email ya está en uso
        
        nuevo_usuario = {
            "nombre": nombre,
            "email": email,
            "password": hashed,
            "is_admin": is_admin
        }
        return self.repo.crear_usuario(AuthUser.from_dict(nuevo_usuario))

    def listar_usuarios(self):
        """Retorna la lista de usuarios (no administradores)"""
        return self.repo.listar_usuarios()
