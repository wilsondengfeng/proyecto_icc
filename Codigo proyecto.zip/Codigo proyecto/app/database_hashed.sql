-- ==========================================
-- BASE DE DATOS: smarthome_webcontrol
-- Versión con admin y usuarios separados
-- ==========================================

CREATE DATABASE IF NOT EXISTS smarthome_webcontrol
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

USE smarthome_webcontrol;

-- ==========================================
-- TABLA: admin
-- ==========================================
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- ==========================================
-- TABLA: usuarios
-- ==========================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- ==========================================
-- TABLA: dispositivos
-- ==========================================
CREATE TABLE dispositivos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo ENUM('luz', 'sensor') NOT NULL,
    estado BOOLEAN DEFAULT FALSE,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ==========================================
-- DATOS INICIALES
-- ==========================================

-- Administrador de prueba
INSERT INTO admin (nombre, email, password)
VALUES ('Admin', 'admin@smarthome.com', 'scrypt:32768:8:1$nkiHvyrT5zf8Wbjf$8764cfa277e09f970d1f1cf3cbd4b476ce728615069a7e1eb4b00c6e1fb3c48e9cd20a77d6b02ca205d2992b3699b39f25460d7b0f1264edbcabf1377d3a31ca');

-- Usuarios de prueba
INSERT INTO usuarios (nombre, email, password)
VALUES
('Wilson Deng', 'wilson@smarthome.com', '123456'), ('Carlo Torres', 'carlo@smarthome.com', 'scrypt:32768:8:1$zvCq8gJiIWPdxYcA$a43e8420ef9bb1f366cea73b13155d25a7865f4db432f53454e97529d679864eba58f56babef729c3027aff09689e5bd4494246ed4360347c9929f4a8121fda4');

-- Dispositivos asociados a usuarios
INSERT INTO dispositivos (nombre, tipo, estado, usuario_id) VALUES
('Luz Sala', 'luz', FALSE, 1),
('Sensor Movimiento', 'sensor', TRUE, 1),
('Luz Cocina', 'luz', TRUE, 2);
